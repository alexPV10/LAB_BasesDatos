/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

//Librerias de conexion con BD
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

// Importacion de los Modelos
import Models.ViewModelEmpleados;
import Models.ViewModelClientes;
import Models.ViewModelProductos;
import Models.ViewModelLaboratorios;
import Models.ViewModelProveedores;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


/**
 *
 * @author Tambo
 */
public class ServletPrincipal extends HttpServlet {
    
    
    //Estableciendo conexion con la BD
    private final String usuario = "AdministradorLogin";
    private final String contrasenia = "root";
    private final String servidor = "LAPTOP-UBF5ENFM\\SQLEXPRESS";
    private final String bd = "Farmacia";
    
    String url = "jdbc:sqlserver://" 
            + servidor 
            + ";databaseName=" + bd 
            + ";user=" + usuario 
            + ";password=" + contrasenia 
            + ";encrypt=false;trustServerCertificate=false;";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletPrincipal</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServletPrincipal at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    
    //FUNCIONES DE CRUD SOBRE LA BASE DE DATOS
    //Funciones de lectura de tablas (SELECT)
    public void mostrarEmpleados(HttpServletRequest request, HttpServletResponse response) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try(Connection conn = DriverManager.getConnection(url)){
                request.setAttribute("mensaje_conexion", "Ok!");
                String sqlQuery = "SELECT * FROM empleado";
                PreparedStatement pstmt = conn.prepareStatement(sqlQuery);
                ResultSet rs = pstmt.executeQuery();
                ArrayList<ViewModelEmpleados> listaEmpleados = new ArrayList<>();
                while (rs.next()) {
                    ViewModelEmpleados empleado = new ViewModelEmpleados();
                    empleado.setId(rs.getInt("ID"));
                    empleado.setNombres(rs.getString("Nombres"));
                    empleado.setApellidos(rs.getString("Apellidos"));
                    empleado.setDui(rs.getString("Dui"));
                    empleado.setIss(rs.getString("Iss"));
                    empleado.setFecha_nacimiento(rs.getDate("Fecha_nacimiento"));
                    empleado.setTelefono(rs.getString("Telefono"));
                    empleado.setCorreo(rs.getString("Correo"));
                    empleado.setIdDireccion(rs.getInt("IdDireccion"));
                    empleado.setIdCargo(rs.getInt("IdCargo"));
                    listaEmpleados.add(empleado);
                    System.out.print(listaEmpleados);
                }         
                                
                request.setAttribute("listaEmpleados", listaEmpleados);

            }
        } catch (SQLException | ClassNotFoundException ex) {
            request.setAttribute("mensaje_conexion", ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    
    public void mostrarClientes(HttpServletRequest request, HttpServletResponse response) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try(Connection conn = DriverManager.getConnection(url)){
                request.setAttribute("mensaje_conexion", "Ok!");
                String sqlQuery = "SELECT * FROM [Farmacia].[dbo].[cliente]";
                PreparedStatement pstmt = conn.prepareStatement(sqlQuery);
                ResultSet rs = pstmt.executeQuery();
                ArrayList<ViewModelClientes> listaClientes = new ArrayList<>();
                while (rs.next()) {
                    ViewModelClientes cliente = new ViewModelClientes();
                    cliente.setId(rs.getInt("ID"));
                    cliente.setNombre(rs.getString("Nombre"));
                    cliente.setApellido(rs.getString("Apellido"));
                    cliente.setDui(rs.getString("Dui"));
                    cliente.setFecha_nacimiento(rs.getDate("Fecha_nacimiento"));
                    cliente.setTelefono(rs.getString("Telefono"));
                    cliente.setCorreo(rs.getString("Correo"));
                    cliente.setIdDireccion(rs.getInt("IdDireccion"));
                    listaClientes.add(cliente);
                    System.out.print(listaClientes);
                }         
                                
                request.setAttribute("listaClientes", listaClientes);

            }
        } catch (SQLException | ClassNotFoundException ex) {
            request.setAttribute("mensaje_conexion", ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    
    public void mostrarProductos(HttpServletRequest request, HttpServletResponse response) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try(Connection conn = DriverManager.getConnection(url)){
                request.setAttribute("mensaje_conexion", "Ok!");
                String sqlQuery = "SELECT * FROM producto";
                PreparedStatement pstmt = conn.prepareStatement(sqlQuery);
                ResultSet rs = pstmt.executeQuery();
                ArrayList<ViewModelProductos> listaProductos = new ArrayList<>();
                while (rs.next()) {
                    ViewModelProductos productos = new ViewModelProductos();
                    productos.setId(rs.getInt("ID"));
                    productos.setNombre(rs.getString("Nombre"));
                    productos.setDescripcion(rs.getString("Descripcion"));
                    productos.setPrecio(rs.getFloat("Precio"));
                    productos.setFechaVencimiento(rs.getDate("FechaVencimiento"));
                    productos.setStockActual(rs.getInt("StockActual"));
                    productos.setStockMinimo(rs.getInt("StockMinimo"));
                    productos.setFechaUltimaCompra(rs.getDate("FechaUltimaCompra"));
                    productos.setFechaUltimaVenta(rs.getDate("FechaUltimaVenta"));
                    productos.setInstrucciones(rs.getString("Instrucciones"));
                    productos.setIdPrecentacion(rs.getInt("IdPrecentacion"));
                    listaProductos.add(productos);
                    System.out.print(listaProductos);
                }         
                                
                request.setAttribute("listaProductos", listaProductos);

            }
        } catch (SQLException | ClassNotFoundException ex) {
            request.setAttribute("mensaje_conexion", ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    public void mostrarLaboratorios(HttpServletRequest request, HttpServletResponse response) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try(Connection conn = DriverManager.getConnection(url)){
                request.setAttribute("mensaje_conexion", "Ok!");
                String sqlQuery = "SELECT * FROM laboratorio";
                PreparedStatement pstmt = conn.prepareStatement(sqlQuery);
                ResultSet rs = pstmt.executeQuery();
                ArrayList<ViewModelLaboratorios> listaLaboratorios = new ArrayList<>();
                while (rs.next()) {
                    ViewModelLaboratorios laboratorios = new ViewModelLaboratorios();
                    laboratorios.setId(rs.getInt("ID"));
                    laboratorios.setNif(rs.getString("NIF"));
                    laboratorios.setNombres(rs.getString("Nombres"));
                    laboratorios.setDescripcion(rs.getString("Descripcion"));
                    laboratorios.setCorreo(rs.getString("Correo"));
                    laboratorios.setTelefono(rs.getString("Telefono"));
                    laboratorios.setIdDireccion(rs.getInt("IdDireccion"));
                    listaLaboratorios.add(laboratorios);
                    System.out.print(listaLaboratorios);
                }         
                                
                request.setAttribute("listaLaboratorios", listaLaboratorios);

            }
        } catch (SQLException | ClassNotFoundException ex) {
            request.setAttribute("mensaje_conexion", ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    public void mostrarProveedores(HttpServletRequest request, HttpServletResponse response) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try(Connection conn = DriverManager.getConnection(url)){
                request.setAttribute("mensaje_conexion", "Ok!");
                String sqlQuery = "SELECT * FROM proveedor";
                PreparedStatement pstmt = conn.prepareStatement(sqlQuery);
                ResultSet rs = pstmt.executeQuery();
                ArrayList<ViewModelProveedores> listaProveedores = new ArrayList<>();
                while (rs.next()) {
                    ViewModelProveedores proveedores = new ViewModelProveedores();
                    proveedores.setId(rs.getInt("ID"));
                    proveedores.setNombreEmpresa(rs.getString("NombreEmpresa"));
                    proveedores.setContactoNombre(rs.getString("ContactoNombre"));
                    proveedores.setContactoTelefono(rs.getString("ContactoTelefono"));
                    proveedores.setDireccion(rs.getString("Direccion"));
                    proveedores.setEmail(rs.getString("Email"));
                    proveedores.setFechaRegistro(rs.getDate("FechaRegistro"));
                    listaProveedores.add(proveedores);
                    System.out.print(listaProveedores);
                }         
                                
                request.setAttribute("listaProveedores", listaProveedores);

            }
        } catch (SQLException | ClassNotFoundException ex) {
            request.setAttribute("mensaje_conexion", ex.getMessage());
            ex.printStackTrace();
        }
    }

    
    
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //REDIRECCIONES DE PAGINAS
        String accion = request.getParameter("accion");
        if (accion == null) {
            request.getRequestDispatcher("/Login.jsp").forward(request, response);
        } else if (accion.equals("Login")) {
            request.getRequestDispatcher("/Login.jsp").forward(request, response);
        } else if (accion.equals("GestionarEmpleados")) {
            mostrarEmpleados(request, response);
            request.getRequestDispatcher("/GestionarEmpleados.jsp").forward(request, response);
        } else if (accion.equals("GestionarClientes")) {
            mostrarClientes(request, response);
            request.getRequestDispatcher("/GestionarClientes.jsp").forward(request, response);
        } else if (accion.equals("GestionarProductos")) {
            mostrarProductos(request, response);
            request.getRequestDispatcher("/GestionarProductos.jsp").forward(request, response);
        }else if (accion.equals("GestionarLaboratorios")) {
            mostrarLaboratorios(request, response);
            request.getRequestDispatcher("/GestionarLaboratorios.jsp").forward(request, response);
        }else if (accion.equals("GestionarProveedores")) {
            mostrarProveedores(request, response);
            request.getRequestDispatcher("/GestionarProveedores.jsp").forward(request, response);
        }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //AUTENTICACION DE CREDENCIALES
        String accion = request.getParameter("accion");

        if (accion.equals("Login")) {
            String usuario = request.getParameter("tfUsuario");
            String contrasenia = request.getParameter("tfContrasenia");

            try (PrintWriter print = response.getWriter()) {
                if (usuario.equals("admin") && contrasenia.equals("root")) {
                    request.getRequestDispatcher("/PanelAdministrador.jsp").forward(request, response);

                } else {
                    print.println("<!DOCTYPE html>");
                    print.println("<html>");
                    print.println("<head>");
                    print.println("<title>Login Farmaceutico</title>");
                    print.println("</head>");
                    print.println("<body>");
                    print.println("<h2>Error: La contraseña o el usuario son erróneos</h2>");
                    print.println("</body>");
                    print.println("</html>");
                }
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
